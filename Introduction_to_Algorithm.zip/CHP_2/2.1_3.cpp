#ifndef FIND_TARGET
#define FIND_TARGET
#include<cstdio>
#include<iostream>
#include<vector>
int main()
{
    std::vector<int> arra;
    int arg;
    std::cout << "请输入一个要查找的整数：" << std::endl;
    int v = 0;
    std::cin >> v;
    std::cout << "请输入一个数组：" << std::endl;
    while(std::cin >> arg)
    {
        arra.push_back(arg);
    }
    auto key = arra.begin();
    for( ; key != arra.end(); ++key)
    {
        if(*key == v)
            {std::cout << key - arra.begin() + 1 << std::endl; break;}    
    }
    if(key == arra.end())
    {
        std::cout << "没有要查找的数字" << std::endl;
    }
    return 0;

}
#endif