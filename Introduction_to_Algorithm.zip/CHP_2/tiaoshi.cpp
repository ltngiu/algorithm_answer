#include<iostream>
#include<stdio.h>
#include<limits.h>
#include<vector>
void Merge(std::vector<int>::iterator pa);
int main(){
    int m =12;
    for(int i = 0; i != m; ++i)
    std::cout << i << " ";
    std::cout << std::endl;
    
}
void Merge(std::vector<int>::iterator pa)
{
    *pa = 0;
    *(pa+1) = 0;
    *(pa+2) = 0;
}