#ifndef binary_sum
#define binary_sum
#include<cstdio>
#include<iostream>
#include<vector>
int main()
{

}
#endif