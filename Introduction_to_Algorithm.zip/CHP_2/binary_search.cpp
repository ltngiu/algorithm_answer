#include <stdioc>
#