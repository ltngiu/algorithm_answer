#ifndef QS
#define QS
#include<cstdio>
#include<iostream>
#include<vector>
void QuikSort (std::vector<int> & A, int p, int r);
int Partition(std::vector<int> &A, int p, int r);
void ex_num(int &a, int &b);
#endif