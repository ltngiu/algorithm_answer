//区间图着色问题，贪心算法：
//两个事件之间空闲时间最小的一个解一定是某一个最优解
//假设两个事件发生时间分别为[1,4), [4, 8)，则某一间教室
//排布为{..., [1,4), [4,8), ...}的一个解必定是最优解之
//一：假设某个最优解某间教室的排布为{..., [1,4), [x, y), ...}
//(x>4), 此时另一间教室的排列为{..., [4, 8), ...}，则只需要将
//{[x, y), ...}与{[4,8), ...}对换即可得到符合要求的最优解
#include<cstdio>
#include<limits.h>
#include<iostream>
#include<vector>
#include<algorithm>
int main(){
    std::vector<int> s = {1, 3, 0, 5, 3, 5, 6, 8, 8, 2, 12};
    std::vector<int> f = {4, 5, 6, 7, 9, 9, 10, 11, 12, 14, 16};
    std::vector<std::vector<int>> classroom(12, std::vector<int>(17));
    std::vector<std::vector<int>> d(s.size(), std::vector<int>(s.size()));
    for(int i = 0; i < s.size(); ++i){
        for(int j = i + 1; j < s.size(); ++j){
            if(f[i] > s[j]) d[i][j] = d[j][i] = 1;
        }
        //构建区间图，值为1的元代表两个活动之间存在冲突，0为不冲突
        //并使用对角元存储每个事件发生的教室编号
    }
    int k = 1;
    //对教室进行编号
    for(int i = 0; i < s.size(); ++i){
        if(d[i][i] == 0){
            //对节点进行遍历，如果该节点还未着色（分配教室），
            //则直接分配一个空闲的教室，并在分配空闲教室后
            //将其视为忙碌状态
            d[i][i] = k;
            ++k;
            int choic= -1;
            int temp = INT_MAX;
            for(int j = i+1; j < s.size(); ++j){
                //因为是顺序遍历，所以节点i前面的节点全都分配了教室
                //从i+1开始遍历节点i后面的节点，并选择与事件i之间
                //浪费时间最少的那个事件作为choic
                if(d[i][j] == 0 && d[j][j] == 0){
                    if(temp > s[j] - f[i]){
                        temp = s[j]-f[i];
                        choic = j;
                    }
                }
            }   
            if(choic >= 0) d[choic][choic] = d[i][i];
            //如果没有选取到choic，则不进行额外的操作
        }
        else{
            //对于已经着色（分配教室）的节点，
            //直接寻找与之兼容的下一个事件，限制条件相同
            int choic = -1;
            int temp = INT_MAX;
            for(int j = i + 1; j < s.size(); ++j){
                if(d[i][j] == 0 && temp > s[j]-f[i] && d[j][j] == 0){
                    temp = s[j] - f[i];
                    choic = j;
                }
            }
            if(choic >= 0) d[choic][choic] = d[i][i];
            //如果没有选取到choic，则不进行额外的操作
        }
    }
    for(int i = 0; i < s.size(); ++i){
        std::cout << d[i][i] << " ";
    }


    return 0;
}