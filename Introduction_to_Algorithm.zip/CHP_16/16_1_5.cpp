//带权的最优活动，动态规划
#include<cstdio>
#include<limits.h>
#include<random>
#include<iostream>
#include<vector>
void print_res(std::vector<std::vector<int>> &p, std::vector<int> &v, std::vector<int> &s, std::vector<int> &f, int i, int j){
    if(p[i][j] != 0){
        print_res(p, v, s, f, i, p[i][j]);
        std::cout << p[i][j] << ": " << v[p[i][j]] << " (" << s[p[i][j]] << ", " << f[p[i][j]] << ")" << std::endl;
        print_res(p, v, s, f, p[i][j], j);
    }
}
int main(){
    std::vector<int> s = {0, 1, 3, 0, 5, 3, 5, 6, 8, 8, 2, 12, 16};
    std::vector<int> f = {0, 4, 5, 6, 7, 9, 9, 10, 11, 12, 14, 16, 16};
    std::default_random_engine e(10);
    std::uniform_int_distribution<int> u(1, 10);
    u(e);
    std::vector<int> v(s.size());
    for(int i = 0; i < v.size(); ++i){
        v[i] = u(e);
        if(i == 0) v[i] = 0;
        if(i == v.size()-1) v[i] = 0;
        std::cout << v[i] << " ";
    }
    std::vector<std::vector<int>> d(s.size(), std::vector<int>(s.size())), p(s.size(), std::vector<int>(s.size()));
    for(int i = 0; i < v.size()-1; ++i){
        d[i][i+1] = 0;
    }
    for(int l = 2; l < s.size(); ++l){
        for(int i = 0; i + l < s.size(); ++i){
            int j = i + l;
            d[i][j] = INT_MIN;
            if(s[j] > f[i]){
                for(int k = i+1; k < j; ++k){
                    if(s[k] >= f[i] && f[k] <= s[j]){
                        int temp = v[k] + d[i][k] + d[k][j];
                        if(temp > d[i][j]){
                            d[i][j] = temp;
                            p[i][j] = k;
                        }
                    }
                }
            }
        }
    }
    std::cout << std::endl;
    print_res(p, v, s, f, 0, s.size()-1);
    return 0;
}