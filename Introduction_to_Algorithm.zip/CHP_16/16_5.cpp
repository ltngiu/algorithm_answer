//离线缓存
#include<cstdio>
#include<iostream>
#include<random>
#include<algorithm>
#include<vector>
int main(){
    int n = 50;
    int k = 3, counter = 0; //缓存大小和用于指示缓存大小的指标
    std::vector<int> r(n); //指令
    std::vector<int> s(k); //缓存
    std::default_random_engine e(10);
    std::uniform_int_distribution<int> u(1, 10);
    int cache_miss = 0;
    for(int i = 0; i < n; ++i){
        r[i] = u(e);
        r[i] = u(e);
        std::cout << r[i] << " " ;
    }
    std::cout << std::endl;
    for(int i = 0; i < n; ++i){
        if(counter == 0){
            s[counter] = r[i];
            std::cout << s[0] << " " << s[1] << " " << s[2] << " " <<r[i] << " " << std::endl;
            ++counter;
            ++cache_miss;
        }
        else if(counter < k){
            if(std::find(s.begin(), s.begin() + counter, r[i]) == s.begin()+counter) {
                s[counter] = r[i]; ++counter; 
                std::cout << s[0] << " " << s[1] << " " << s[2] << " " << r[i] << " " << std::endl; 
                ++cache_miss;
            }
            else continue;
        }
        else{
            if(std::find(s.begin(), s.end(), r[i]) == s.end()){
                ++cache_miss;
                std::vector<int> res(counter+1);
                for(int j = 0; j < counter; ++j){
                    res[j] = std::find(r.begin() + i, r.end(), s[j]) - r.begin();
                }
                res[counter] = std::find(r.begin() + i+1, r.end(), r[i]) - r.begin();
                int temp = (std::max_element(res.begin(), res.end())) - res.begin();
                // std::cout << "res: ";
                // for(int j = 0; j < counter+1; ++j){
                //     std::cout << res[j] << " ";
                // }
                if(temp < counter){
                    // std::cout << "temp: " << temp << " " 
                    // << s[0] << " " << s[1] << " " << s[2] << " "<< r[i] << " " << s[temp] << " " << std::endl;
                    s[temp] = r[i];
                    
                }
            }
            else continue;
        }
    }
    std::cout << std::endl;
    std::cout << cache_miss;
    return 0;
}