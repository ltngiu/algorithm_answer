#include<cstdio>
#include<string>
#include<iostream>
#include<deque>
#include<vector>
class word{
    public:
    word * left_child = NULL;
    word * right_child = NULL;
    char w;
    double freq = 0.0;
    std::string code;
    bool root = false;
    word(char a, double f, bool r): left_child(NULL), right_child(NULL), w(a), freq(f), root(r){};
    word(word* l, word* r, double f, bool ro): left_child(l), right_child(r), freq(f), root(ro){};
};

word* Huff_mann(std::deque<char> & ws, std::deque<double> &freq){ 
    std::vector<word*> words;
    for(int i = 0; i < ws.size(); ++i){
        words[i] = new word(ws[i], freq[i], false);
    }
}