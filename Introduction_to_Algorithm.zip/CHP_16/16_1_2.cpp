#include<cstdio>
#include<iostream>
#include<vector>
int main(){
    std::vector<int> s = {1, 3, 0, 5, 3, 5, 6, 8, 8, 2, 12};
    std::vector<int> f = {4, 5, 6, 7, 9, 9, 10, 11, 12, 14, 16};
    int n = s.size();
    std::vector<int> ret;
    ret.push_back(s.size()-1);
    int k = s.size()-1;
    for(int key = s.size()-2; key >= 0; --key){
        if(f[key] <= s[k]){
            ret.push_back(key);
            k = key;
        }
    }
    std::cout << "一个最好的活动安排是：" << std::endl;
    for(auto key = ret.crbegin(); key != ret.crend(); ++key)
        std::cout << *key << " " ;
    std::cout << std::endl;
    std::cout << "最多可以安排" << ret.size() << "个活动";
    return 0;
}