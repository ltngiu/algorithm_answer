//0-1背包问题
#include<cstdio>
#include<vector>
#include<iostream>
using namespace::std;
int main(){
    vector<int> weight = {10,20,30};
    vector<int> value = {60,100,120};
    int bagWeight = 50;
    vector<vector<int>> dp(weight.size(), vector<int>(bagWeight + 1, 0));
    for(int i = weight[0]; i <= bagWeight; ++i)
        dp[0][i] = value[0];
    for(int i = 1; i < weight.size(); ++i)
        for(int j = 0; j <= bagWeight; ++j){
            if(j < weight[i]) dp[i][j] = dp[i-1][j];
            else{
                dp[i][j] = max(dp[i-1][j], dp[i - 1][j-weight[i]] + value[i]);
            }
        }
    int ways[weight.size()];
    int c = bagWeight;
    for(int i = weight.size() - 1; i >= 0; --i){
        if(i == 0){
            ways[i] = 1 ? 0 : dp[i][c] > 0;
        }
        else {if(dp[i][c] == dp[i-1][c]) ways[i - 1] = 0;
        else{
            ways[i] = 1;  c = c - weight[i];
        }}
    }
    std::cout<< "分配方案为:" << std::endl;
    for(int i = 0; i < weight.size(); ++i)
        std::cout << ways[i] << " " ;
    std::cout << std::endl; 
    std::cout << dp[weight.size()-1][bagWeight] << std::endl;
    return 0;
}