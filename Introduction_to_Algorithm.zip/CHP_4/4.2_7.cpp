#include<cstdio>
#include<iostream>
int main()
{
    
}