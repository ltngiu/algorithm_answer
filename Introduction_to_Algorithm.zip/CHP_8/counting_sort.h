#ifndef countsort
#define countsort
#include<cstdio>
#include<iostream>
#include<vector>

void counting_sort(std::vector<int> &A, std::vector<int> &B, int k);


#endif