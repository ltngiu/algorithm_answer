#ifndef mmt
#define mmt
#include<iostream>
#include<cstdio>
#include<vector>
#include<limits.h>
std::vector<std::vector<std::vector<int>>> matrix_chain(std::vector<int> p);

#endif