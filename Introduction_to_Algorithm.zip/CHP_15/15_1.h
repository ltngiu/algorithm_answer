#ifndef fif_one
#define fif_one
#include<cstdio>
#include<limits.h>
#include<vector>
#include<iostream>
std::vector<std::vector<double>> GPT(int n);
std::vector<std::vector<double>> longest(std::vector<std::vector<double>> &A, std::vector<std::vector<double>> weight, int beg, int term);
#endif