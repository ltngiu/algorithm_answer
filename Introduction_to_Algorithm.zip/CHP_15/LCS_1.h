#ifndef LCS1
#define LCS1
#include<vector>
#include<iostream>
#include<cstdio>
std::vector<int> LCS_LENGTH(std::vector<int> &X, std::vector<int> &Y);

#endif